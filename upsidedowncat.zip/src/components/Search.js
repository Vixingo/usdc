"use client";
import { Box, Button, TextField } from "@mui/material";
import React, { useState } from "react";
import Slider from "@mui/material/Slider";
function Search() {
    const [show, setShow] = useState(false);
    return (
        <>
            <div className="flex gap-4 justify-center">
                <input
                    type="text"
                    placeholder="Find a cat"
                    style={{
                        color: "#fff",
                        backgroundColor: "#8b684d",
                        outline: "none",
                        borderRadius: "8px",
                        padding: "8px",
                        fontSize: "30px",
                        maxWidth: "250px",
                    }}
                />
                <Button
                    variant="contained"
                    sx={{
                        borderRadius: "8px",
                        backgroundColor: "#8b684d",
                    }}
                    color="warning"
                >
                    Random <br /> Cat
                </Button>
                <Button
                    variant="contained"
                    sx={{
                        borderRadius: "8px",
                        backgroundColor: "#8b684d",
                    }}
                    color="warning"
                    onClick={() => setShow(!show)}
                >
                    {show ? "Show" : "hide"} <br /> 18+
                </Button>
            </div>
            <Box sx={{ width: 300, margin: "12px auto" }}>
                {" "}
                <Slider
                    size="small"
                    defaultValue={70}
                    aria-label="Small"
                    valueLabelDisplay="auto"
                />
            </Box>
        </>
    );
}

export default Search;
