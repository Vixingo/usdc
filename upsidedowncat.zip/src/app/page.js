import Header from "@/components/Header";
import Search from "@/components/Search";
import Image from "next/image";

export default function Home() {
    return (
        <>
            <Header />
            <Search />
        </>
    );
}
